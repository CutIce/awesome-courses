import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private LineSegment[] store;

    public BruteCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException("Points are null");
        ArrayList<LineSegment> list = new ArrayList<>();
        int num = points.length;
        store = new LineSegment[num];
        // for (int i = 0; i < num; ++i) {
        //     Point p = points[i];
        //     for (int j = 0; j < num && j != i; ++j) {
        //         Point q = points[j];
        //         for (int k = 0; k < num && k != i && k != j; ++k) {
        //             Point r = points[k];
        //             for (int h = 0; h < num && h != i && h != j && h != k; ++h) {
        //                 Point s = points[h];
        //
        //                 if (p.slopeTo(q) == p.slopeTo(r) && p.slopeTo(q) == p.slopeTo(s)) {
        //                     LineSegment newone = new LineSegment(p, find_remote(p, q, r, s));
        //                     store[number] = newone;
        //                     ++number;
        //                 }
        //             }
        //         }
        //     }
        // }

        for (int i = 0; i < num; ++i) {
            Point p = points[i];
            for (int j = i + 1; j < num; ++j) {
                Point q = points[j];
                for (int k = j + 1; k < num; ++k) {
                    Point r = points[k];
                    for (int h = k + 1; h < num; ++h) {
                        Point s = points[h];

                        if (p.slopeTo(q) == p.slopeTo(r) && p.slopeTo(q) == p.slopeTo(s)) {
                            list.add(new LineSegment(p, s));
                        }
                    }
                }
            }
        }

        store = new LineSegment[list.size()];
        list.toArray(store);
    }


    public int numberOfSegments() {
        return store.length;
    }


    public LineSegment[] segments() {
        return Arrays.copyOf(store, store.length);
    }

    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }

}
