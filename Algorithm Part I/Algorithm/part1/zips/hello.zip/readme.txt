////////////////////////
// HELLO WORLD README //
////////////////////////

Name:

NetID:

//////////////////////
// Course logistics //
//////////////////////

Do you have a laptop that you can bring to precept?

If so, what operating system do you use?

Which text editor are you using to edit this file? (We recommend IntelliJ!)

Have you taken part of COS 126 before?

Number of hours to complete this assignment:

//////////////////////////////////////////////////////////////
// Some information to help your preceptor get to know you. //
//////////////////////////////////////////////////////////////

Nickname (i.e., what you prefer to be called in class):

Year:

AB/BSE:

Possible major(s) (if you know or have an idea):

Confidence level (0 = very afraid, 5 = very confident):

Do you have any previous programming experience?

Why are you interested in taking this course?

What are your other interests?


/////////////////////////////////////////////////////////
// Part of Assignment 0 is to fill out a Google form.  //
/////////////////////////////////////////////////////////

Did you do this, yes or no?

/////////////////////////////////////////////////////////////////////////
// Another part of Assignment 0 is to read the collaboration policy on //
// the syllabus and get 100% on the Collaboration Policy quiz. You can //
// take the quiz as many times as needed.)                             //
/////////////////////////////////////////////////////////////////////////

Did you do this, yes or no?

/////////////////////////////////////////////////////////////
// When (date and time) are the four exams in this course? //
/////////////////////////////////////////////////////////////

Written Exam 1: 

Programming Exam 1:

Written Exam 2:

Programming Exam 2:

////////////////////////////////////////////////////////////////////////////////
// Please check your calendar. Do you have any potential scheduling conflicts //
// with any of these dates? If so, what is/are the conflict?                  //
////////////////////////////////////////////////////////////////////////////////

Yes or no?

If yes, please specify:

//////////////////////////////////////////////////////////////////
// Did you receive help from classmates, past COS 126 students, //
// or anyone else? If so, list his/her/their name(s) here.      //
// ("A Sunday Lab TA" or "Office hours on Thursday" is ok.)     //
//////////////////////////////////////////////////////////////////

Yes or no? 

If yes, please specify/describe:

//////////////////////////////////////////////////////////////////////
// Did you encounter any serious problems? If yes, please describe. //
//////////////////////////////////////////////////////////////////////

Yes or no? 

If yes, please describe:
